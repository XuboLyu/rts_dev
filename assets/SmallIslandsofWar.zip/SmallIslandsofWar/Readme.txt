Name:		Small Islands of War
Author:		Headbusta02
Address: 		adrainef@msn.com  
Editor:		Final Alert 2 (FA2)
Created:		11th February 2004
Size:		90x95 (180k)
Players:		1-2
Theater:		Temperate

Description: Plenty of ore and gems also plenty of buildings to capture and plenty of ways to defend but may not be that much room for those who like to have a lot, so conserve on building room.

Install Instructions: Simply put Small Islands of War.mpr  in the RA2 directory 


More Coming Soon!